### Add support for Centos distro
We are planning to add support for Centos distribution

### Add example for QEMU VM with 256 cores and 8 NUMA nodes with 3 different NUMA distances
It is important (interesting) to push the limits a little bit :)

